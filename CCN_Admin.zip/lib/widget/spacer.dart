
import 'package:flutter/material.dart';

Widget spacer(double size) {
  return SizedBox(
    height: size,
  );
}
