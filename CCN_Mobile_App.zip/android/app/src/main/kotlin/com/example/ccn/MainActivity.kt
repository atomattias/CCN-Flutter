package com.example.ccn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
