library utils;

import 'dart:async';

import 'package:ccn/screens/auth/signin.dart';
import 'package:ccn/screens/auth/signup.dart';
import 'package:ccn/screens/landing.dart';
import 'package:ccn/screens/loader.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

part 'app_router.dart';
part 'app_theme.dart';
part 'text_theme.dart';
part 'http.dart';
