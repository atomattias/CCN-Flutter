library models;

import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.dart';

part '_index.freezed.dart';
part '_index.g.dart';
