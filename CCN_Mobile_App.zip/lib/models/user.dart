// ignore_for_file: invalid_annotation_target

part of models;

@freezed
class User with _$User {
  const factory User({
    @JsonKey(name: "_id") required String id,
    required String fullname,
    required String email,
    String? address,
    String? country,
    String? phone,
    String? role,
    String? status,
  }) = _User;

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
}
