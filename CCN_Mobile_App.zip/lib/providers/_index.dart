library providers;

import 'dart:async';

import 'package:ccn/models/_index.dart';
import 'package:ccn/utils/_index.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

part 'auth.dart';
