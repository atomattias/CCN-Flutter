part of providers;

final authProvider = ChangeNotifierProvider((ref) => AuthProvider(ref));

class AuthProvider extends ChangeNotifier {
  late Ref ref;
  late Dio http;
  User? user;
  late HttpProvider prov;
  AuthProvider(this.ref) {
    init();
  }

  init() {
    prov = ref.read(httpProvider);
    http = prov.http;
  }

// logic for login
  Future<bool> login({email, password}) async {
    final resp = await prov.handler(
      func: () => http.post("/api/auth/signin", data: {
        "email": email,
        "password": password,
      }),
    );
    if (resp.status == Status.successful) {
      prov.saveToken(resp.data["data"]["token"]);
      user = User.fromJson(resp.data["data"]);
      return true;
    } else {
      return false;
    }
  }

// logic for signing up
  Future<bool> register({email, username, phone, password}) async {
    final resp = await prov.handler(
      func: () => http.post("/api/auth/signup", data: {
        "email": email,
        "username": username,
        "phone": phone,
        "password": password,
      }),
    );
    if (resp.status == Status.successful) {
      prov.saveToken(resp.data["token"]);
      return true;
    } else {
      return false;
    }
  }

// logic for logging out
  Future logout() async {
    await ref.read(httpProvider).deleteToken();
  }
}
